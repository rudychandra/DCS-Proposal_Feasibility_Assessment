-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Apr 2018 pada 16.03
-- Versi server: 10.1.30-MariaDB
-- Versi PHP: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kelayakanproposal`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `Judul_proposal` text NOT NULL,
  `kriteria1` int(11) NOT NULL,
  `kriteria2` int(11) NOT NULL,
  `kriteria3` int(11) NOT NULL,
  `kriteria4` int(11) NOT NULL,
  `keterangan` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`Judul_proposal`, `kriteria1`, `kriteria2`, `kriteria3`, `kriteria4`, `keterangan`) VALUES
('a', 9, 8, 7, 8, '9'),
('b', 8, 9, 9, 6, '8'),
('c', 9, 3, 2, 7, '4'),
('d', 8, 4, 5, 2, '6'),
('e', 5, 6, 7, 5, '6');

-- --------------------------------------------------------

--
-- Struktur dari tabel `biodataproposal`
--

CREATE TABLE `biodataproposal` (
  `Nama` varchar(30) NOT NULL,
  `Instansi_asal` varchar(50) NOT NULL,
  `Judul_proposal` text NOT NULL,
  `Deskripsi_proposal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `biodataproposal`
--

INSERT INTO `biodataproposal` (`Nama`, `Instansi_asal`, `Judul_proposal`, `Deskripsi_proposal`) VALUES
('Rudy Chandra', 'a', 'a', 'a'),
('raja hafiz al ihsan', 'b', 'b', 'b'),
('ramadhan syahputra', 'c', 'c', 'c'),
('Farid akbar', 'd', 'd', 'd'),
('otong', 'e', 'e', 'e');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
