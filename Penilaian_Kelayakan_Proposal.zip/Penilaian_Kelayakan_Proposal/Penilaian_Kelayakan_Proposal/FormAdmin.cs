﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Penilaian_Kelayakan_Proposal
{
    public partial class FormAdmin : Form
    {
        string[] judul;
		double[] be, pp,kp,mp;
        int[] lulus = new int[12];
        int[] tlulus = new int[12];
        String[] bulan = { "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" };

        SQLiteConnection sql = new SQLiteConnection("Data Source=kelayakanproposal.db;Version=3;");
        public FormAdmin()
        {
            InitializeComponent();
        }
        
        private void FormAdmin_Load(object sender, EventArgs e)
        {
            chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
            refresh();
        }

        public void refresh()
        {
            sql.Open();
            DataTable dt = new DataTable();
            SQLiteDataAdapter da = new SQLiteDataAdapter("SELECT * FROM admin WHERE BE IS NULL OR PP IS NULL OR KP IS NULL OR MP IS NULL OR BE = '' OR PP = '' OR KP = '' OR MP = ''", sql);
            da.Fill(dt);
            dataGridView3.Columns.Clear();
            dataGridView3.DataSource = dt.DefaultView;
            dataGridView3.Columns[0].HeaderText = "Judul Proposal";
            DataGridViewButtonColumn bukaa = new DataGridViewButtonColumn();
            bukaa.HeaderText = "Open File";
            bukaa.Text = "Open";
            bukaa.UseColumnTextForButtonValue = true;
            dataGridView3.Columns.Add(bukaa);

            DataTable dtt = new DataTable();
            SQLiteDataAdapter daa = new SQLiteDataAdapter("SELECT * FROM admin WHERE BE IS NOT NULL AND PP IS NOT NULL AND KP IS NOT NULL AND MP IS NOT NULL", sql);
            daa.Fill(dtt);
            dataGridView4.Columns.Clear();
            dataGridView4.DataSource = dtt.DefaultView;
            dataGridView4.Columns[0].HeaderText = "Judul Proposal";
            DataGridViewButtonColumn buka = new DataGridViewButtonColumn();
            buka.HeaderText = "Open File";
            buka.Text = "Open";
            buka.UseColumnTextForButtonValue = true;
            dataGridView4.Columns.Add(buka);
            sql.Close();
            loadgrafik();

        }

        public void loadgrafik()
        {
            lulus = new int[12];
            tlulus = new int[12];
            sql.Open();
            SQLiteCommand del;
            SQLiteDataReader sqlReader;
            for(int i =0; i<12;i++)
            {
                del = new SQLiteCommand("select Judul_proposal from admin where bulan ='" + bulan[i]+ "' and Kelayakan = 'layak'", sql);
                sqlReader = del.ExecuteReader();
                try
                {
                    while (sqlReader.Read())
                    {
                        lulus[i]++;
                    }
                }
                catch (Exception ex)
                {
                }

                del = new SQLiteCommand("select Judul_proposal from admin where bulan ='" + bulan[i] + "' and Kelayakan = 'tidak layak'", sql);
                sqlReader = del.ExecuteReader();
                try
                {
                    while (sqlReader.Read())
                    {
                        tlulus[i]++;
                    }
                }
                catch (Exception ex)
                {
                }
            }
            foreach (var series in chart1.Series)
            {
                series.Points.Clear();
            }

            chart1.Series["Layak"].Points.AddXY("Jan", lulus[0]);
            chart1.Series["Tidak Layak"].Points.AddXY("Jan", tlulus[0]);
            chart1.Series["Layak"].Points.AddXY("Feb", lulus[1]);
            chart1.Series["Tidak Layak"].Points.AddXY("Feb", tlulus[1]);
            chart1.Series["Layak"].Points.AddXY("Mar", lulus[2]);
            chart1.Series["Tidak Layak"].Points.AddXY("Mar", tlulus[2]);
            chart1.Series["Layak"].Points.AddXY("Apr", lulus[3]);
            chart1.Series["Tidak Layak"].Points.AddXY("Apr", tlulus[3]);
            chart1.Series["Layak"].Points.AddXY("Mei", lulus[4]);
            chart1.Series["Tidak Layak"].Points.AddXY("Mei", tlulus[4]);
            chart1.Series["Layak"].Points.AddXY("Jun", lulus[5]);
            chart1.Series["Tidak Layak"].Points.AddXY("Jun", tlulus[5]);
            chart1.Series["Layak"].Points.AddXY("Jul", lulus[6]);
            chart1.Series["Tidak Layak"].Points.AddXY("Jul", tlulus[6]);
            chart1.Series["Layak"].Points.AddXY("Ags", lulus[7]);
            chart1.Series["Tidak Layak"].Points.AddXY("Ags", tlulus[7]);
            chart1.Series["Layak"].Points.AddXY("Spt", lulus[8]);
            chart1.Series["Tidak Layak"].Points.AddXY("Spt", tlulus[8]);
            chart1.Series["Layak"].Points.AddXY("Okt", lulus[9]);
            chart1.Series["Tidak Layak"].Points.AddXY("Okt", tlulus[9]);
            chart1.Series["Layak"].Points.AddXY("Nov", lulus[10]);
            chart1.Series["Tidak Layak"].Points.AddXY("Nov", tlulus[10]);
            chart1.Series["Layak"].Points.AddXY("Des", lulus[11]);
            chart1.Series["Tidak Layak"].Points.AddXY("Des", tlulus[11]);

            sql.Close();

        }

        public string bayes(int be, int pp, int kp, int mp)
        {
            string hasilbayes;
            double pl = 0, ptl = 0, bel = 0, betl = 0, ppl = 0, pptl = 0, kpl = 0, kptl = 0, mpl = 0, mptl = 0, bandingl, bandingtl;
            for (int i = 0; i < dataGridView4.Rows.Count; i++)
            {
                
                if ((dataGridView4[6, i].Value.ToString()) == "layak")
                    pl = pl + 1;
                else if ((dataGridView4[6, i].Value.ToString()) == "tidak layak")
                    ptl = ptl + 1;

                if ((dataGridView4[6, i].Value.ToString()) == "layak" && Convert.ToInt32(dataGridView4[2, i].Value.ToString()) == be)
                    bel = bel + 1;
                else if ((dataGridView4[6, i].Value.ToString()) == "tidak layak" && Convert.ToInt32(dataGridView4[2, i].Value.ToString()) == be)
                    betl = betl + 1;

                if ((dataGridView4[6, i].Value.ToString()) == "layak" && Convert.ToInt32(dataGridView4[3, i].Value.ToString()) == pp)
                    ppl = ppl + 1;
                else if ((dataGridView4[6, i].Value.ToString()) == "tidak layak" && Convert.ToInt32(dataGridView4[3, i].Value.ToString()) == pp)
                    pptl = pptl + 1;

                if ((dataGridView4[6, i].Value.ToString()) == "layak" && Convert.ToInt32(dataGridView4[4, i].Value.ToString()) == kp)
                    kpl = kpl + 1;
                else if ((dataGridView4[6, i].Value.ToString()) == "tidak layak" && Convert.ToInt32(dataGridView4[4, i].Value.ToString()) == kp)
                    kptl = kptl + 1;

                if ((dataGridView4[6, i].Value.ToString()) == "layak" && Convert.ToInt32(dataGridView4[5, i].Value.ToString()) == mp)
                    mpl = mpl + 1;
                else if ((dataGridView4[6, i].Value.ToString()) == "tidak layak" && Convert.ToInt32(dataGridView4[5, i].Value.ToString()) == mp)
                    mptl = mptl + 1;
            }
            ppl = ppl / pl;
            pptl = pptl / ptl;
            bel = bel / pl;
            betl = betl / ptl;
            kpl = kpl / pl;
            kptl = kptl / ptl;
           mpl = mpl / pl;
            mptl = mptl / ptl;
            pl = pl / (dataGridView4.Rows.Count - 1);
            ptl = ptl / (dataGridView4.Rows.Count - 1);

            bandingl = ppl*bel*kpl*mpl;
            bandingtl = pptl*betl*kptl*mptl;
            if (bandingl > bandingtl)
                hasilbayes = "layak";
            else
                hasilbayes = "tidak layak";
            return hasilbayes;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
             sql.Open();
             string judul = dataGridView3.CurrentRow.Cells[0].Value.ToString();
             if (judul == "" || comboBox1.Text == "" || textBox1.Text == "" || comboBoxkriteria3.Text == "" || comboBoxkriteria2.Text == "")
             {
                 MessageBox.Show("data tidak boleh kosong !!");
             }
             else
             {
                 double be = Convert.ToDouble(textBox1.Text);
                if (be <= 15)
                    be = 1;
                else if (be > 15 && be <= 30)
                    be = 2;
                else if (be > 30 && be <= 45)
                    be = 3;
                else if (be > 45 && be <= 60)
                    be = 4;
                else
                    be = 5;                
                 int pp = Convert.ToInt32(comboBoxkriteria2.Text);
                 int kp = Convert.ToInt32(comboBoxkriteria3.Text);
                 int mp = Convert.ToInt32(comboBox1.Text);
                 string layak = bayes(Convert.ToInt32(be), pp, kp, mp);
                 SQLiteCommand cmd = new SQLiteCommand("update admin set BE = " +be+", PP =" +pp+", KP ="+kp+ ", MP =" + mp + ", Kelayakan = '" + layak+"' where Judul_proposal = '"+judul+"'", sql);
                 cmd.ExecuteNonQuery();
             }
             sql.Close();
             refresh();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            sql.Open();
            DataTable dt = new DataTable();
            SQLiteDataAdapter da = new SQLiteDataAdapter("SELECT * FROM admin WHERE Kelayakan = 'layak'", sql);
            da.Fill(dt);
            dataGridView2.Columns.Clear();
            dataGridView2.DataSource = dt.DefaultView;
            dataGridView2.Columns[0].HeaderText = "Judul Proposal";
            sql.Close();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < 12; i++)
            {
                if(comboBox3.Text == bulan[i])
                {
                    label20.Text = lulus[i].ToString();
                    label21.Text = tlulus[i].ToString();
                    label19.Text = (lulus[i] + tlulus[i]).ToString();
                }
            }
        }

        private void btnRanking_Click_1(object sender, EventArgs e)
        {
            judul = new string[dataGridView2.Rows.Count];
            be = new double[dataGridView2.Rows.Count];
            pp = new double[dataGridView2.Rows.Count];
            kp = new double[dataGridView2.Rows.Count];
            mp = new double[dataGridView2.Rows.Count];
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                judul[i] = dataGridView2[0, i].Value.ToString();
                be[i] = Convert.ToDouble(dataGridView2[2, i].Value.ToString());
                pp[i] = Convert.ToDouble(dataGridView2[3, i].Value.ToString());
                kp[i] = Convert.ToDouble(dataGridView2[4, i].Value.ToString());
                mp[i] = Convert.ToDouble(dataGridView2[5, i].Value.ToString());
            }

            //membangun matriks
            double[,] x = new double[judul.Length, 4];
            for (int i = 0; i < judul.Length; i++)
            {
                x[i, 0] = be[i];
                x[i, 1] = pp[i];
                x[i, 2] = kp[i];
                x[i, 3] = mp[i];
            }

            //normalisasi matriks
            double[,] r = new double[judul.Length, 4];
            for (int j = 0; j < 4; j++)
            {
                double sigma = 0;
                for (int i = 0; i < judul.Length; i++)
                {
                    sigma = sigma + Math.Pow(x[i, j], 2);
                }
                for (int i = 0; i < judul.Length; i++)
                {
                    r[i, j] = Math.Round(x[i, j] / Math.Sqrt(sigma), 3);
                }
            }

            //normalisasi bobot
            double[] bobot = { 2, 2, 3, 4 };
            for (int i = 0; i < judul.Length; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    r[i, j] = Math.Round(r[i, j] * bobot[j], 3);
                }
            }

            //v- dan v+
            double[] vmin = new double[4], vmax = new double[4];
            for (int j = 0; j < 4; j++)
            {
                vmin[j] = r[0, j];
                vmax[j] = r[0, j];
                for (int i = 1; i < judul.Length; i++)
                {
                    if (vmin[j] > r[i, j])
                        vmin[j] = r[i, j];
                    if (vmax[j] < r[i, j])
                        vmax[j] = r[i, j];
                }
            }

            //d- dan d+
            double[] dmin = new double[judul.Length], dmax = new double[judul.Length];
            for (int i = 0; i < judul.Length; i++)
            {
                double totaldmax = 0, totaldmin = 0;
                for (int j = 0; j < 4; j++)
                {
                    totaldmax = totaldmax + Math.Pow(vmax[j] - r[i, j], 2);
                    totaldmin = totaldmin + Math.Pow(r[i, j] - vmin[j], 2);
                }
                dmax[i] = Math.Round(Math.Sqrt(totaldmax), 3);
                dmin[i] = Math.Round(Math.Sqrt(totaldmin), 3);
            }

            //RPI
            double[] rpi = new double[judul.Length];
            for (int i = 0; i < judul.Length; i++)
            {
                rpi[i] = Math.Round(dmin[i] / (dmax[i] + dmin[i]), 3);
            }

            dataGridView1.ColumnCount = 4;
            dataGridView1.Columns[0].Name = "Judul Proposal";
            dataGridView1.Columns[1].Name = "d+";
            dataGridView1.Columns[2].Name = "d-";
            dataGridView1.Columns[3].Name = "RPI";

            for (int i = 0; i < judul.Length; i++)
            {
                dataGridView1.Rows.Add(judul[i], dmax[i], dmin[i], rpi[i]);
            }
            dataGridView1.Sort(dataGridView1.Columns[3], ListSortDirection.Descending);
        }

        private void dataGridView3_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            sql.Open();
            string filename = "";
            int col = e.ColumnIndex, row = e.RowIndex;
            if (col.Equals(7))
            {
                SQLiteCommand cmd = new SQLiteCommand("SELECT Filename FROM biodataproposal where Judul_Proposal = '" + dataGridView3[0, row].Value.ToString() + "'", sql);
                SQLiteDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    filename = reader.GetString(0);
                }
                reader.Close();
                string startupPath1 = System.IO.Directory.GetCurrentDirectory();
                startupPath1 += "\\proposal";
                string destFile = System.IO.Path.Combine(startupPath1, filename);
                System.Diagnostics.Process.Start(destFile);
            }
            sql.Close();
        }

        private void dataGridView4_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            sql.Open();
            string filename = "";
            int col = e.ColumnIndex, row = e.RowIndex;
            if (col.Equals(7))
            {
                SQLiteCommand cmd = new SQLiteCommand("SELECT Filename FROM biodataproposal where Judul_Proposal = '" + dataGridView4[0, row].Value.ToString() + "'", sql);
                SQLiteDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    filename = reader.GetString(0);
                }
                reader.Close();
                string startupPath1 = System.IO.Directory.GetCurrentDirectory();
                startupPath1 += "\\proposal";
                string destFile = System.IO.Path.Combine(startupPath1, filename);
                System.Diagnostics.Process.Start(destFile);
            }
            sql.Close();
        }

        
    }
}
