﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace Penilaian_Kelayakan_Proposal
{
    public partial class FormUser : Form
    {
        string filename = "";
        SQLiteConnection sql = new SQLiteConnection("Data Source=kelayakanproposal.db;Version=3;");
        public FormUser()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 fruser = new Form1();
            fruser.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog open = new OpenFileDialog();
                open.Filter = "PDF Files( *.pdf)|*.pdf";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = Path.GetFullPath(open.FileName);
                    filename = open.SafeFileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || txtInstansi.Text == "" || txtNama.Text == "" || richTextBox1.Text == "" || richTextBox2.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("data tidak boleh ada yg kosong");
            }
            else
            {
                sql.Open();
                SQLiteCommand cmd = new SQLiteCommand("insert into biodataproposal values('" + txtNama.Text + "','" + txtInstansi.Text + "','" + richTextBox2.Text + "','" + comboBox1.Text + "','" + richTextBox1.Text + "','" + filename + "')", sql);
                cmd.ExecuteNonQuery();
                SQLiteCommand cmdd = new SQLiteCommand("INSERT INTO admin (Judul_proposal, bulan)VALUES('" + richTextBox2.Text + "','" + comboBox1.Text + "')", sql);
                cmdd.ExecuteNonQuery();
                string startupPath1 = System.IO.Directory.GetCurrentDirectory();
                startupPath1 += "\\proposal";
                string sourceFile = textBox1.Text;
                string destFile = System.IO.Path.Combine(startupPath1, filename);

                System.IO.File.Copy(sourceFile, destFile, true);
                MessageBox.Show("data berhasil disimpan");
                textBox1.Text = "";
                txtInstansi.Text = "";
                txtNama.Text = "";
                richTextBox1.Text = "";
                richTextBox2.Text = "";
                comboBox1.Text = "";
                sql.Close();
            }
        }
    }
}
